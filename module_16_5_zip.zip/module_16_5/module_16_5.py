from fastapi import FastAPI, status, Path, HTTPException, Request, Form
from fastapi.responses import HTMLResponse  #  HTMLResponse - ответ
from typing import Annotated
from pydantic import BaseModel
from typing import List
from fastapi.templating import Jinja2Templates  #  Позволяет подключить директорию, в которой будем
                                                # обрабатывать шаблоны (templates)

app = FastAPI()
templates = Jinja2Templates(directory="templates")  #  Указывается рабочая папка "templates"

users = []

class User(BaseModel):
    id: int
    username: str
    age: int

#  GET  "/"
@app.get("/", status_code=status.HTTP_201_CREATED)
def new_users(request: Request) -> HTMLResponse:
    return templates.TemplateResponse("users.html", {"request": request, "users": users})


@app.get("/user/{user_id}")  #  На запрос /user/{user_id} выводим данные конкретного пользователя
def get_user(request: Request, user_id: int) -> HTMLResponse:
    user = next(user for user in users if user.id == user_id)  #  Находим в списке users пользователя с соответствующим
                                                               # идентификатором user_id
    return templates.TemplateResponse("users.html", {"request": request, "user": user})  # Передаем пользователя

#  POST
@app.post("/user/{username}/{age}")  #  На запрос /user/{username}/{age} вносим нового пользователя
def new_user(username: Annotated[str, Path(min_length=2,                     # Минимальная длина username
                                            max_length=20,                      # Максимальная длина username
                                            description="Enter your username",  # описание для ввода username
                                            examples="User")],                   # пример
                   age: Annotated[int, Path(ge=10,                    # age только больше или равен 18
                                            le=100,                   # age не более 100
                                            description="Enter age",  # описание для ввода age
                                            examples=24)]) -> User:            # пример

    new_id = (users[-1].id + 1) if users else 1
    new_user = User(id=new_id, username=username, age=age)
    users.append(new_user)
    return new_user



#  PUT
@app.put("/user/{user_id}/{username}/{age}")
def edit_user(
    user_id: Annotated[int, Path(ge=1,
                                 le=50,
                                 description="Enter user_id",
                                 examples=1)],
    username: Annotated[str, Path(min_length=2,
                                  max_length=20,
                                  description="Enter your username",
                                  examples="User")],
    age: Annotated[int, Path(ge=10,
                             le=100,
                             description="Enter age",
                             examples=24)]) ->str:
    for user in users:
        if user.id == user_id:
            user.username = username
            user.age = age
            return str(user)
    raise HTTPException(status_code=404, detail="User was not found")

#  DELETE
@app.delete("/user/{user_id}")
def del_user(
        user_id: Annotated[int, Path(
            ge=1,
            le=50,
            description="Enter user_id",
            examples=1)]):
    for user in users:
        if user.id == user_id:
            users.remove(user)
            return user
    raise HTTPException(status_code=404, detail="User was not found")


"""
  Запускаем в терминале PyCharm
python -m uvicorn module_16_5:app  
      где module_16_5 - имя файла, 
      app - объект FastAPI() в коде module_16_5.py

Для входа в FastAPI Swagger UI вводим http://127.0.0.1:8000/docs
"""